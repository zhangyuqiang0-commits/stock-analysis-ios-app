# 股票分析 iOS 原生 App

这是第二种方案：真正的 iPhone App，包含自己的图标、完整 UI、图形和同花顺 App 跳转。

运行时不需要电脑，也不需要服务器。电脑只用于一次性的云端编译和免费签名安装。

## 目录说明

- Sources/StockAnalysisApp.swift：App 入口
- Sources/WebAppView.swift：WKWebView 原生壳和同花顺跳转
- Resources/app.html：完整股票分析界面和数据逻辑
- Resources/Assets.xcassets：App 图标
- project.yml：XcodeGen 工程配置
- .github/workflows/build-unsigned-ipa.yml：GitHub 云端编译未签名 IPA

## 第一步：用 GitHub Actions 编译 IPA

1. 注册或登录 GitHub。
2. 新建一个仓库，可以是 Private。
3. 把 stock-analysis-ios-app 目录内的全部文件上传到仓库。
4. 打开仓库的 Actions 页面。
5. 选择 Build unsigned IPA。
6. 点击 Run workflow。
7. 等待约 5-10 分钟。
8. 在构建结果底部下载 StockAnalysis-unsigned.ipa。

## 第二步：Windows 免费签名安装

需要：

- Windows 电脑
- iPhone 数据线
- Sideloadly
- 普通 Apple ID

步骤：

1. 在 Windows 安装 Sideloadly。
2. 用数据线连接 iPhone，并在手机上选择“信任此电脑”。
3. 打开 Sideloadly。
4. 把 StockAnalysis-unsigned.ipa 拖入 Sideloadly。
5. 输入自己的 Apple ID。
6. 点击 Start。
7. 输入 Apple ID 密码或验证码。
8. 安装完成后，在 iPhone 设置中打开“开发者模式”。
9. 在 设置 -> 通用 -> VPN与设备管理 中信任自己的开发者证书。

## 重要限制

免费 Apple ID 签名的 App 通常只有7天有效期。

- 7天后 App 会无法打开。
- 需要重新连接 Windows 电脑，用 Sideloadly 重新安装一次。
- 使用同一个 Bundle ID 重新签名时，App 数据通常可以保留。
- 如果不想每7天续签，需要加入 Apple Developer Program，约99美元/年，然后使用 TestFlight 或 Ad Hoc 安装。

## 同花顺跳转

App 会依次尝试：

- mttzzq://quote?code=股票代码
- mttzzq://stock?code=股票代码
- mttzzq://
- hexin://
- 10jqka://
- 官方网页通用链接

如果某个 URL Scheme 在你的同花顺版本不可用，会自动尝试下一个。

## 说明

这个工程需要在 macOS 或 GitHub Actions 上编译。当前环境是 Windows，无法在本机直接生成可安装的 IPA。
