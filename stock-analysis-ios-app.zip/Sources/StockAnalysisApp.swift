import SwiftUI

@main
struct StockAnalysisApp: App {
    var body: some Scene {
        WindowGroup {
            WebAppView()
                .ignoresSafeArea()
                .preferredColorScheme(.light)
        }
    }
}
