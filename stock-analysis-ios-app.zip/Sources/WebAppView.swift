import SwiftUI
import WebKit

struct WebAppView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.websiteDataStore = .default()
        configuration.userContentController.add(context.coordinator, name: "stockBridge")

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear

        if let file = Bundle.main.url(forResource: "app", withExtension: "html") {
            let directory = file.deletingLastPathComponent()
            webView.loadFileURL(file, allowingReadAccessTo: directory)
        }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "stockBridge",
                  let body = message.body as? [String: Any],
                  let action = body["action"] as? String else { return }

            if action == "ths", let code = body["code"] as? String {
                openTonghuashun(code: code)
            }
        }

        private func openTonghuashun(code: String) {
            let schemes = [
                "mttzzq://quote?code=\(code)",
                "mttzzq://stock?code=\(code)",
                "mttzzq://",
                "hexin://",
                "10jqka://"
            ]
            let fallback = URL(string: "https://stockpage.10jqka.com.cn/\(code)/")!
            for value in schemes {
                if let url = URL(string: value), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                    return
                }
            }
            UIApplication.shared.open(fallback)
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { decisionHandler(.allow); return }
            if url.isFileURL || url.scheme == "about" { decisionHandler(.allow); return }
            if url.scheme == "http" || url.scheme == "https" {
                if navigationAction.navigationType == .linkActivated {
                    UIApplication.shared.open(url)
                    decisionHandler(.cancel)
                    return
                }
                decisionHandler(.allow)
                return
            }
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
